<?php

require_once APPPATH . '/models/BaseModel.php';

class CodeModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'register_code';
    }

    public function set_code_use( $code_id, $circle_id ){
        $now = time();
        $in_data = array(
            'circle_id' => $circle_id,
            'status' => '103',
            'use_time' => $now
        );

        $this->update( $code_id, $in_data );
    }

    public function check_code_valid( $code ){
        $code_info = $this->get_code_info( $code );
        if( !$code_info ){
            throw new OpException( '注册码无效', ERROR_CODE_PARAM_INVALID );
        }
        return $code_info['id'];
    }

    public function get_code_info( $code ){
        $code_info = $this->getByFields( array('code', 'status'), array( $code, '102') );
        return $code_info;
    }

    /*
     * 每次生成一定数量的注册码
     *
     * */

    public function init(){
        $count = 100;

        for( $inx=0; $inx<$count; $inx++){
            $code = mt_rand( 100000, 999999 );
            if( $this->getByField( 'code', $code ) ){
                $inx--;
                continue;
            }
            $in_data = array(
                'code' => $code,
                'status' => '101'
            );
            $this->insert( $in_data );
        }

    }
}