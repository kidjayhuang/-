<?php

require_once APPPATH . '/models/BaseModel.php';

class MemberModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'member';
    }


    public function get_last_time( $circle_id, $user_id ){
        $last_time = $this->redis->hget( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'last_time' );
        if( $last_time ){
            $member = $this->getByFields(
                                array('circle_id', 'user_id', 'status'),
                                array($circle_id, $user_id, 0 ),
                                array('remark', 'last_time') );
            $this->redis->hset( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'last_time', $member['last_time'] );
            if( $member['remark'] != '' ){
                $this->redis->hset( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'remark', $member['remark'] );
            }
        }
        return $last_time;
    }

    public function  set_last_time( $circle_id, $user_id ){
        $now = time();
        $this->update_where( array( 'last_time' => $now),
            array( 'circle_id' => $circle_id,
                   'user_id' => $user_id,
                   'status' => 0 )
        );

        $this->redis->hset( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'last_time', $now );
    }

    public function del( $circle_id, $user_id ){
        $this->update_where( array( 'status' => 1,
                                    'quit_time' => time()),
                             array( 'circle_id' => $circle_id,
                                    'user_id' => $user_id,
                                    'status' => 0 )
        );

        //群成员缓存
        if( $this->is_member( $circle_id, $user_id ) ) {
            $this->redis->zrem(REDIS_KEY_MEMBER . $circle_id, $user_id);
        }
        else {
            $this->redis->zrem(REDIS_KEY_MEMBER . $circle_id, $user_id);
        }

        //我的圈子缓存
        $this->redis->zrem( REDIS_KEY_MYCIRCLE . $user_id, $circle_id );

    }

    //建群时调用，写数据库即可
    public function create( $circle_id, $user_id ){
        $now = time();
        $in_data = array(
            'circle_id' => $circle_id,
            'user_id' => $user_id,
            'join_time' => $now,
            'type' => USER_TYPE_CREATOR
        );

        $this->insert( $in_data );

        //设置我的圈子缓存
        if( !$this->redis->zAdd( REDIS_KEY_MYCIRCLE . $user_id, $now, $circle_id )){
            throw new OpException( '设置缓存错误', ERROR_CODE_REDIS_FAIL );
        }

        return true;
    }

    public function admin_list( $circle_id ){
        return $this->redis->zrevrangebyscore( REDIS_KEY_ADMIN . $circle_id, time(), 0 );
    }

    public function member_list( $circle_id, $page=0 ){
        if( $page==0 ) {
            return $this->redis->zrevrange(REDIS_KEY_MEMBER . $circle_id, 0, LIMIT_CIRCLE_MEMBER-1);
        }
        else{
            $start = ($page-1) * MEMBER_COUNT_PAGE;
            $stop = $start + MEMBER_COUNT_PAGE - 1;
            return $this->redis->zrevrange(REDIS_KEY_MEMBER . $circle_id, $start, $stop );
        }
    }

    //备注数据准备性要求较低，直接从缓存读取即可
    public function get_remark( $circle_id, $user_id ){
        $remark = $this->redis->hget( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'remark' );
        if( !$remark ){
            return false;
        }
        return $remark;
    }

    //
    public function is_admin( $circle_id, $user_id ){
        $score = $this->redis->zscore( REDIS_KEY_ADMIN . $circle_id, $user_id );
        if( !$score ){
            return false;
        }
        return true;
    }


    public function is_member( $circle_id, $user_id ){
        $score = $this->redis->zscore( REDIS_KEY_MEMBER . $circle_id, $user_id );
        if( !$score ){
            return false;
        }
        return true;
    }

    //设置圈子备注名称
    public function set_remark( $circle_id, $user_id, $remark ){
        //设置
        $this->update_where( array( 'remark' => $remark ),
            array( 'circle_id' => $circle_id,
                'user_id' => $user_id,
                'status' => 0 )
        );

        $this->redis->hset( REDIS_KEY_MEMBER_INFO . $circle_id . REDIS_SEPARATOR . $user_id, 'remark', $remark );
    }

    //加入圈子
    public function join( $circle_id, $user_id ){
        $now = time();

        $my_circle_count = $this->redis->zcard( REDIS_KEY_MYCIRCLE . $user_id );
        if( $my_circle_count >= LIMIT_JOIN_CIRCLE ){
            throw new OpException( '假如的圈子数量超过了限制', ERROR_CODE_EXCEED );
        }

        $in_data = array(
            'circle_id' => $circle_id,
            'user_id' => $user_id,
            'join_time' => $now,
            'type' => USER_TYPE_MEMBER
        );

        $this->insert( $in_data );

        //设置成员列表缓存
        if( !$this->redis->zAdd( REDIS_KEY_MEMBER . $circle_id, $now, $user_id )){
            throw new OpException( '设置圈子成员缓存错误', ERROR_CODE_REDIS_FAIL );
        }

        //设置我的圈子缓存
        if( !$this->redis->zAdd( REDIS_KEY_MYCIRCLE . $user_id, $now, $circle_id )){
            throw new OpException( '设置我的圈子缓存错误', ERROR_CODE_REDIS_FAIL );
        }

        return true;
    }

    public function my_circle( $user_id ){
        return $this->redis->zrevrange( REDIS_KEY_MYCIRCLE . $user_id, 0, LIMIT_JOIN_CIRCLE );
    }

    //设置为管理员
    public function set_admin( $circle_id, $user_id ){
        if( $this->is_admin( $circle_id, $user_id )){
            throw new OpException( '已经是管理员', ERROR_CODE_USER_IDENTIFY );
        }

        $this->update_where( array( 'type' => USER_TYPE_ADMIN ),
                             array( 'circle_id' => $circle_id,
                                    'user_id'=> $user_id,
                                    'status' => 0 ));
        $this->redis->zrem( REDIS_KEY_MEMBER . $circle_id, $user_id );
        $this->redis->zAdd( REDIS_KEY_ADMIN . $circle_id, time(), $user_id );
    }

    //取消管理员设置
    public function cancel_admin( $circle_id, $user_id ){
        if( $this->is_member( $circle_id, $user_id )){
            throw new OpException( '不是管理员', ERROR_CODE_USER_IDENTIFY );
        }
        $this->update_where( array( 'type' => USER_TYPE_MEMBER ),
            array( 'circle_id' => $circle_id,
                'user_id'=> $user_id ));
        $this->redis->zrem( REDIS_KEY_ADMIN . $circle_id, $user_id );
        $this->redis->zAdd( REDIS_KEY_MEMBER . $circle_id, time(), $user_id );
    }

}