<?php

require_once APPPATH . '/models/BaseModel.php';

class CircleModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'circle';
    }

    public function set_attr( $circle_id, $field, $val ){
        if( $field == 'name' ){
            //验证重名
            if( $this->redis->get( REDIS_KEY_CIRCLE_NAME . $val ) == '1' ){
                throw new OpException( '圈子名称已经存在', ERROR_CODE_PARAM_INVALID );
            }
        }

        $this->update( $circle_id, array( $field => $val ));
        $this->redis->hset( REDIS_KEY_CIRCLE . $circle_id, $field, $val );
    }

    public function get_user_count( $user_id ){
        $sql = "SELECT count(1) as cnt
                FROM $this->table_name
                WHERE creator = ?";

        $query = $this->db->query( $sql, array( $user_id ) );
        $res = $query->row_array();
        if( $res ){
            return $res['cnt'];
        }
        return 0;
    }

    public function create( $user_id, $data ){
        //验证重名
        if( $this->redis->get( REDIS_KEY_CIRCLE_NAME . $data['name'] ) == '1' ){
            throw new OpException( '圈子名称已经存在', ERROR_CODE_PARAM_INVALID );
        }

        //先写数据库
        $in_data = $data;
        $in_data['creator'] = $user_id;
        $in_data['banner'] = DEFAULT_CIRCLE_BANNER;
        $in_data['create_time'] = time();
        $in_data['update_time'] = $in_data['create_time'];
        $in_data['member_count'] = 1;

        $circle_id = $this->insert( $in_data );

        //写缓存
        $cache_data = $data;
        $cache_data['creator'] = $user_id;
        $cache_data['banner'] = DEFAULT_CIRCLE_BANNER;
        $cache_data['create_time'] = $in_data['create_time'];
        $cache_data['member_count'] = 1;

        $this->redis->hmset( REDIS_KEY_CIRCLE . $circle_id, $cache_data );

        $this->redis->set( REDIS_KEY_CIRCLE_NAME . $in_data['name'], '1' );

        return $circle_id;
    }

    public function get_basic_info( $circle_id ){
        $circle_info = $this->redis->hgetall( REDIS_KEY_CIRCLE . $circle_id );

        if( !$circle_info ){
            $circle_db = $this->getById( $circle_id );
            if( !$circle_db ){
                throw new OpException( '查找的圈子不存在', ERROR_CODE_NOT_EXIST );
            }

            //存在但是没有缓存的话，刷新缓存
            $circle_info = array(
                'creator' => $circle_db['creator'],
                'anyone_view' => $circle_db['anyone_view'],
                'join_verify' => $circle_db['join_verify'],
                'thumb' => $circle_db['thumb'],
                'banner' => $circle_db['banner'],
                'desc' => $circle_db['desc'],
                'name' => $circle_db['name'],
                'create_time' => $circle_db['create_time'],
                'update_time' => $circle_db['update_time'],
                'member_count' => $circle_db['member_count'],
            );

            $this->redis->hmset( REDIS_KEY_CIRCLE . $circle_id, $circle_info );

        }
        return $circle_info;
    }

    public function member_join( $circle_id ){
        $member_count = $this->redis->hget( REDIS_KEY_CIRCLE . $circle_id, 'member_count' );
        if( $member_count ){
            $this->redis->hset( REDIS_KEY_CIRCLE . $circle_id, 'member_count', ++$member_count );
            $this->update( $circle_id, array( 'member_count' => $member_count ));
        }
    }

    public function member_quit( $circle_id )
    {
        $member_count = $this->redis->hget(REDIS_KEY_CIRCLE . $circle_id, 'member_count');
        if ($member_count) {
            $this->redis->hset(REDIS_KEY_CIRCLE . $circle_id, 'member_count', --$member_count);
            $this->update($circle_id, array('member_count' => $member_count));
        }
    }

}