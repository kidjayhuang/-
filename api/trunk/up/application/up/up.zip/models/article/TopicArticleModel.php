<?php

require_once APPPATH . '/models/BaseModel.php';

class TopicArticleModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'topic_article';
    }

    public function get_top( $circle_id, $topic ){
        return $this->redis->zrevrange( REDIS_KEY_TOPIC_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, 0, LIMIT_TOP_ARTICLE );
    }

    public function get_list( $circle_id, $topic, $page=1 ){
        $start = ($page-1) * ARTICLE_COUNT_PAGE;
        $stop = $start + ARTICLE_COUNT_PAGE - 1;
        return $this->redis->zrevrange( REDIS_KEY_TOPIC_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, $start, $stop );
    }


    public function set( $circle_id, $topic, $topic_id, $article_id ){
        $in_data = array(
            'circle_id' => $circle_id,
            'topic' => $topic,
            'topic_id' => $topic_id,
            'article_id' => $article_id
        );
        $this->insert( $in_data );
        //设置话题下的文章列表缓存

        $this->redis->zAdd( REDIS_KEY_TOPIC_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, time(), $article_id );
    }

    public function set_top( $circle_id, $topic, $article_id ){
        $this->redis->zrem( REDIS_KEY_TOPIC_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, $article_id );
        $this->redis->zAdd( REDIS_KEY_TOPIC_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, time(), $article_id );
    }

    public function cancel_top( $circle_id, $topic, $article_id ){
        $this->redis->zrem( REDIS_KEY_TOPIC_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, $article_id );
        $this->redis->zAdd( REDIS_KEY_TOPIC_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, time(), $article_id );
    }

    public function cancel( $circle_id, $topic, $article_id ){
        $condition = array(
            'circle_id' => $circle_id,
            'topic' => $topic,
            'article_id' => $article_id
        );

        $this->delete( $condition );

        $this->redis->zrem( REDIS_KEY_TOPIC_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, $article_id );
        $this->redis->zrem( REDIS_KEY_TOPIC_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $topic, $article_id );
    }


}