<?php

require_once APPPATH . '/models/BaseModel.php';

class ArticleLogicModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();

        $this->load->model( 'circle/CircleLogicModel', 'circleLogic' );
        $this->load->model( 'article/ArticleLikeModel', 'articleLike' );
        $this->load->model( 'article/ArticleModel', 'article' );
        $this->load->model( 'article/ReplyModel', 'reply' );
        $this->load->model( 'article/TopicModel', 'topic' );
        $this->load->model( 'article/TopicArticleModel', 'topicArticle' );

        $this->_circle_id = 0;
        $this->_circle_info = [];
        $this->_user_id = 0;
    }



    public function write_simple( $text, $pics ){
        $article_id = $this->article->write_simple( $text, $pics, $this->_circle_id, $this->_user_id );

        //处理话题
        $topic_list = $this->_process_topic( $text );

        if( count( $topic_list ) > 0 ) {
            $topic_info_list = $this->topic->process($this->_circle_id, $this->_user_id, $topic_list);
            //print_r($topic_info_list);
            foreach( $topic_info_list as $info ){
                $this->topicArticle->set($this->_circle_id, $info['topic'], $info['id'], $article_id);
            }
        }

        //设置圈子的更新时间
        $this->circleLogic->set_update_time( $this->_circle_id );

        return $article_id;
    }

    public function reply_to_me( $page ){
        $reply_list = $this->reply->to_me_list( $this->_circle_id, $this->_user_id, $page );
        $res=[];
        if( !$reply_list ){
            return $res;
        }

        foreach( $reply_list as $re ){
            $reply_basic_info = json_decode( $re );
            $info = [];
            $info['type'] = $reply_basic_info->type;
            if( $reply_basic_info->type == REPLY_TYPE_LIKE ){  //喜欢
                if( !isset($reply_basic_info->user_id) ){
                    continue;
                }
                $info['time'] = timestamp_trans( $this->articleLike->time( $reply_basic_info->id, $reply_basic_info->user_id) );
                $info['article_id'] = $reply_basic_info->id;
                $info['user_id'] = $reply_basic_info->user_id;
                $info['banner'] = $this->article->get_attr( $info['article_id'], 'banner' );
                $info['user_info'] = $this->circleLogic->user_simple_profile( $this->_circle_id, $reply_basic_info->user_id );
            }
            else if( $reply_basic_info->type == REPLY_TYPE_ARTICLE ) {
                $reply_id = $reply_basic_info->id;
                $reply_info = $this->reply->get_info( $reply_id );
                $info['type'] = $reply_info['type'];
                $info['reply_id'] = $reply_id;
                $info['content'] = $reply_info['content'];
                $info['time'] = timestamp_trans( $reply_info['create_time'] );
                $info['user_id'] = $reply_info['user_id'];
                $info['article_id'] = $reply_info['article_id'];
                $info['banner'] = $this->article->get_attr( $info['article_id'], 'banner' );
                $info['user_info'] = $this->circleLogic->user_simple_profile( $this->_circle_id, $info['user_id'] );

                if( $info['type'] == REPLY_TYPE_REPLY ){
                    $info['to_user_id'] = $reply_info['to_user_id'];
                    $info['to_user_info'] = $info['user_info'] = $this->circleLogic->user_simple_profile( $this->_circle_id, $info['to_user_id'] );
                }
            }
            else{
                continue;
            }

            $res[] = $info;

        }

        return $res;
    }


    public function reply_to_me_count(){
        $this->load->model( 'circle/memberModel', 'member' );
        $last_time = $this->member->get_last_time( $this->_circle_id, $this->_user_id );

        return $this->reply->count_to_me( $this->_circle_id, $this->_user_id, $last_time );
    }


    public function update_times(){
        $this->load->model( 'circle/memberModel', 'member' );
        $last_time = $this->member->get_last_time( $this->_circle_id, $this->_user_id );

        return $this->article->count( $this->_circle_id, $last_time );
    }

    public function hot_topic( ){
        $list_hot = $this->topic->get_hot( $this->_circle_id, LIMIT_TOPIC_HOT );
        return $list_hot;
    }

    public function reply_list( $article_id, $page ){
        $res = [];
        $reply_id_list = $this->reply->get_list( $article_id, $page );
        if( is_array( $reply_id_list ) && count( $reply_id_list ) > 0 ){

            foreach( $reply_id_list as $reply_id ){
                $reply_info = $this->_get_reply_info( $reply_id );
                if( $reply_info ){
                    $res[] = $reply_info;
                }
            }
        }

        return $res;
    }

    public function like_list( $article_id ){
        $res = [];
        $like_user_id = $this->articleLike->get_all( $article_id );
        if( is_array( $like_user_id ) && count( $like_user_id ) > 0 ) {
            foreach( $like_user_id as $user_id ){
                $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $user_id );
                if( $user_info ){
                    $user_info['user_id'] = $user_id;
                    $res[] = $user_info;
                }
            }
        }

        return $res;
    }


    public function rich_info( $article_id ){
        //文章内容
        $article_info = $this->article->get_basic_info( $article_id );
        if( !$article_info ){
            throw new OpException( '文章不存在', ERROR_CODE_NOT_EXIST );
        }

        if( $article_info['type'] == ARTICLE_TYPE_SIMPLE ){
            $article_info['content'] = json_decode( $article_info['content']);
        }

        //发帖人信息
        $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $article_info['user_id'] );
        if( !$user_info ){
            throw new OpException( '发帖人不存在', ERROR_CODE_NOT_EXIST );
        }
        $article_info['user_info'] = $user_info;

        //回复
        $article_info['reply_count'] = $this->reply->count( $article_id );
        $article_info['like_count'] = $this->articleLike->count( $article_id );
        $article_info['create_time'] = timestamp_trans( $article_info['create_time'] );

        return $article_info;
    }

    public function topic_article_list( $topic, $page=1 ){
        $res = array();
        if( $page == 1 ) {
            $top_id = $this->topicArticle->get_top($this->_circle_id, $topic );
            $top_list = $this->_get_list_article_info($top_id);
            $res['top'] = $top_list;
        }

        $id_list = $this->topicArticle->get_list( $this->_circle_id, $topic, $page );
        $res['list'] = $this->_get_list_article_info( $id_list );

        return $res;
    }

    public function article_list( $page=1 ){
        $res = array();
        if( $page == 1 ) {
            $top_id = $this->article->get_top($this->_circle_id);
            $top_list = $this->_get_list_article_info($top_id);
            $res['top'] = $top_list;
        }

        $id_list = $this->article->get_list( $this->_circle_id, $page );
        $res['list'] = $this->_get_list_article_info( $id_list );

        return $res;
    }

    public function like( $article_id, $type ){
        $article_info = $this->article->get_info( $article_id );
        $to_user_id = $article_info['user_id'];

        if( $type == 1 ){
            $this->articleLike->add( $this->_circle_id, $article_id, $this->_user_id, $to_user_id );
        }
        else if( $type == 0 ){
            $this->articleLike->cancel( $this->_circle_id, $article_id, $this->_user_id, $to_user_id );
        }
        else{
            throw new OpException( '错误的操作类型', ERROR_CODE_PARAM_INVALID );
        }
    }

    public function do_reply( $article_id, $to_user_id, $type, $content ){
        $article_info = $this->article->get_info( $article_id );
        if( $type == REPLY_TYPE_ARTICLE ){
            $to_user_id = $article_info['user_id'];
        }

        $reply_id = $this->reply->add( $this->_circle_id, $article_id, $this->_user_id, $to_user_id, $type, $content );

        return $reply_id;

        //暂时先不写回复数量的冗余字段
    }

    function del_reply( $reply_id ){
        $reply_info = $this->reply->get_info( $reply_id );
        if( $reply_info['user_id'] != $this->_user_id ){
            $this->_check_admin();
        }
        $this->reply->del( $this->_circle_id, $reply_id, $reply_info['article_id'], $reply_info['to_user_id'] );
    }

    function del( $article_id ){
        $article_info = $this->article->get_info( $article_id );
        if( $article_info['user_id'] != $this->_user_id ){
            $this->_check_admin();
        }
        $this->article->del( $this->_circle_id, $article_id, $article_info['user_id']);

        //去除话题关联
        $topic_list = $this->_process_topic( $article_info['abstract'] );
        if( count( $topic_list ) ){
            foreach( $topic_list as $topic ) {
                $this->topicArticle->cancel($this->_circle_id, $topic, $article_id );
                //更新话题的得分
                $this->topic->down( $this->_circle_id, $topic );
            }
        }
    }

    function top_oper( $article_id, $type ){
        $this->_check_admin();
        $article_info = $this->article->get_info( $article_id );

        if( $type == 1 ){
            $this->article->set_top( $this->_circle_id, $article_id, $article_info['user_id']);
        }
        else{
            $this->article->cancel_top( $this->_circle_id, $article_id, $article_info['user_id']);
        }

        $topic_list = $this->_process_topic( $article_info['abstract'] );
        if( count( $topic_list ) ){
            foreach( $topic_list as $topic ) {
                if( $type == 1 ) {
                    $this->topicArticle->set_top($this->_circle_id, $topic, $article_id);
                }
                else{
                    $this->topicArticle->cancel_top($this->_circle_id, $topic, $article_id);
                }
            }
        }
    }

    /**
     * 查询推荐话题
     */
    public function get_recommend_topic(){
        return $this->topic->get_recommend( $this->_circle_id );
    }

    /**
     *  设置推荐话题
     */

    public function set_recommend_topic( $topic_text ){
        $this->_check_admin();

        //处理话题
        $topic_list = $this->_process_topic( $topic_text );

        $cnt = count( $topic_list );
        if( $cnt > LIMIT_TOPIC_RECOMMEND ){
            throw new OpException( '推荐话题数量超限', ERROR_CODE_EXCEED );
        }

        if( $cnt > 0 ) {
            $topic_info_list = $this->topic->process($this->_circle_id, $this->_user_id, $topic_list);
            $this->topic->set_recommend( $this->_circle_id, $topic_info_list );
        }

    }

    /*
     * 处理字符串，返回其中包含的话题列表
     */
    public function _process_topic( $text ){
        $res = array();
        $idx = 0;
        $times = 0;
        $last_pos = 0;
        $pos = strpos( $text, CHAR_TOPIC_DELI, $idx );
        while( $pos !== FALSE ){
            if( ++$times % 2 == 0 ){
                $topic = substr( $text, $last_pos+1, $pos-$last_pos-1 );
                if( strlen( $topic )>= LIMIT_TOPIC_LENGTH ){
                    throw new OpException( '话题长度过长', ERROR_CODE_PARAM_INVALID );
                }
                $res[] = $topic;
            }
            else{
                $last_pos = $pos;
            }
            $idx = $pos+1;
            $pos = strpos( $text, CHAR_TOPIC_DELI, $idx );
        }

        return $res;
    }

    public function init( $user_id, $circle_id, $circle_info, $update_time=true ){

        if( !$this->circleLogic->in_circle( $circle_id, $user_id, $circle_info['creator'] )) {
            throw new OpException('不是圈子成员', ERROR_CODE_IN_CIRCLE);
        }
        $this->_circle_id = $circle_id;
        $this->_circle_info = $circle_info;
        $this->_user_id = $user_id;

        if( $update_time ) {
            $this->load->model('circle/MemberModel', 'member');
            $this->member->set_last_time($circle_id, $user_id);
        }

    }

    public function test(  ){
        return $this->_circle_info;
    }

    private function _check_admin(){
        if( !$this->circleLogic->in_admin( $this->_circle_id, $this->_user_id, $this->_circle_info['creator']) ){
            throw new OpException( '不是管理员', ERROR_CODE_NOT_ADMIN );
        }
    }

    private function _get_list_article_info( $list ){
        $res = [];
        if( !$list ){
            return $res;
        }

        foreach( $list as $article_id ){
            //文章内容
            $article_info = $this->article->get_basic_info( $article_id );
            if( !$article_info ){
                continue;
            }
            $article_info['id'] = $article_id;
            $article_info['create_time'] = timestamp_trans( $article_info['create_time'] );
            if( $article_info['type'] == ARTICLE_TYPE_SIMPLE ){
                $article_info['content'] = json_decode( $article_info['content']);
            }


            //发帖人信息
            $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $article_info['user_id'] );
            if( !$user_info ){
                continue;
            }
            $article_info['user_info'] = $user_info;

            //回复
            $article_info['reply_count'] = $this->reply->count( $article_id );
            $article_info['reply_list'] = [];
            $reply_id_list = $this->reply->get_list( $article_id, 1, 5 );
            if( is_array( $reply_id_list ) && count( $reply_id_list ) > 0 ){
                $reply_count = 0;
                foreach( $reply_id_list as $reply_id ){
                    $reply_info = $this->_get_reply_info( $reply_id );
                    if( $reply_info ){
                        $article_info['reply_list'][] = $reply_info;
                        if( ++$reply_count >= 2 ){
                            break;
                        }
                    }
                }
            }

            //点赞
            $article_info['like_count'] = $this->articleLike->count( $article_id );
            $article_info['like_list'] = [];
            $like_user_id = $this->articleLike->get_list( $article_id, 1, 20 );
            if( is_array( $like_user_id ) && count( $like_user_id ) > 0 ) {
                $like_count = 0;
                foreach( $like_user_id as $user_id ){
                    $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $user_id );
                    if( $user_info ){
                        $user_info['user_id'] = $user_id;
                        $article_info['like_list'][] = $user_info;
                        if( ++$like_count >= 7 ){
                            break;
                        }
                    }
                }
            }

            $res[] = $article_info;

        }
        return $res;
    }


    private function _get_reply_info( $reply_id ){
        $reply_basic_info = $this->reply->get_info( $reply_id );
        if( !$reply_basic_info ){
            return false;
        }

        $res = array();
        $res['reply_id'] = $reply_id;
        $res['type'] = $reply_basic_info['type'];
        $res['user_id'] = $reply_basic_info['user_id'];
        $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $res['user_id'] );
        if( !$user_info ){
            return false;
        }
        $res['user_info'] = $user_info;

        if( $reply_basic_info['type'] == REPLY_TYPE_REPLY ){
            $res['to_user_id'] = intval($reply_basic_info['to_user_id']);
            if( $res['to_user_id'] >  0 ){
                $user_info = $this->circleLogic->user_simple_profile( $this->_circle_id, $res['to_user_id'] );
                if( $user_info ){
                    $res['to_user_info'] = $user_info;
                }
                else{
                    $res['to_user_id'] = 0;
                }
            }
        }

        $res['content'] = $reply_basic_info['content'];
        return $res;
    }
}