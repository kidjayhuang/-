<?php

require_once APPPATH . '/models/BaseModel.php';

class TopicModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'topic';
    }

    public function get_recommend( $circle_id ){
        $res = $this->redis->zrange( REDIS_KEY_RECOMMEND_TOPIC . $circle_id, 0, LIMIT_TOPIC_RECOMMEND );
        if( !$res ){
            return [];
        }
        return $res;
    }

    public function get_hot( $circle_id, $cnt ){
        $res = $this->redis->zrevrange( REDIS_KEY_TOPIC_LIST . $circle_id, 0, $cnt-1 );
        if( !$res ){
            return [];
        }
        return $res;
    }

    public function set_recommend( $circle_id, $topic_info_list ){
        $this->update_where( array('status' => TOPIC_STATUS_NORMAL ), array( 'circle_id' => $circle_id, 'status' => TOPIC_STATUS_RECOMMEND ) );
        $this->redis->zremrangebyrank( REDIS_KEY_RECOMMEND_TOPIC . $circle_id, 0, LIMIT_TOPIC_RECOMMEND );

        $score = 0;
        foreach( $topic_info_list as $topic_info ){
            $this->update( $topic_info['id'], array( 'status'=>TOPIC_STATUS_RECOMMEND ));
            $this->redis->zAdd( REDIS_KEY_RECOMMEND_TOPIC . $circle_id, ++$score, $topic_info['topic']);
        }
    }
    public function process( $circle_id, $user_id, $list ){
        $topic_list = array();

        foreach( $list as $topic ){
            $topic_info = $this->get_topic_info( $circle_id, $topic );
            if( !$topic_info ){
                $topic_info = $this->add( $circle_id, $user_id, $topic );
            }
            else{
                $this->up( $circle_id, $topic );
            }
            $topic_list[] = $topic_info;
        }

        return $topic_list;
    }


    public function up( $circle_id, $topic ){
        $score = $this->redis->zscore( REDIS_KEY_TOPIC_LIST . $circle_id, $topic );
        $score = intval($score);
        $this->redis->zAdd( REDIS_KEY_TOPIC_LIST . $circle_id, ++$score, $topic );

    }

    public function down( $circle_id, $topic ){
        $score = $this->redis->zscore( REDIS_KEY_TOPIC_LIST . $circle_id, $topic );
        $score = intval($score);
        $this->redis->zAdd( REDIS_KEY_TOPIC_LIST . $circle_id, --$score, $topic );

    }

    public function add( $circle_id, $user_id, $topic ){
        $now = time();
        $in_data = array(
            'circle_id' => $circle_id,
            'user_id' => $user_id,
            'topic' => $topic,
            'status' => TOPIC_STATUS_NORMAL,
            'create_time' => $now
        );

        $topic_id = $this->insert( $in_data );
        $in_data['id'] = $topic_id;

        //设置topic信息缓存
        $this->redis->hmset( REDIS_KEY_TOPIC . $circle_id . REDIS_SEPARATOR . $topic, $in_data );

        //设置topic_list 缓存
        $this->redis->zAdd( REDIS_KEY_TOPIC_LIST . $circle_id, 1, $topic );
        return $in_data;
    }

    public function get_topic_info( $circle_id, $topic ){
        $topic_info = $this->redis->hgetall( REDIS_KEY_TOPIC . $circle_id . REDIS_SEPARATOR . $topic );
        if( !$topic_info ){
            $topic_info = $this->getByFields( array( 'circle_id', 'topic' ), array( $circle_id, $topic ) );
            if( $topic_info ){
                $this->redis->hmset( REDIS_KEY_TOPIC . $circle_id . REDIS_SEPARATOR . $topic, $topic_info );
            }
            else{
                return FALSE;
            }
        }
        return $topic_info;
    }

}