<?php

require_once APPPATH . '/models/BaseModel.php';

class ArticleModel extends BaseModel
{
    public function __construct()
    {
        parent::__construct();
        $this->table_name = 'article';
    }

    public function  count( $circle_id, $from_timestamp ){
        $now = time();
        $top_count = $this->redis->zcount( REDIS_KEY_CIRCLE_TOP_ARTICLE . $circle_id, $from_timestamp, $now );
        $list_count = $this->redis->zcount( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $from_timestamp, $now );

        return $top_count + $list_count;
    }

    public function get_top( $circle_id ){
         return $this->redis->zrevrange( REDIS_KEY_CIRCLE_TOP_ARTICLE . $circle_id, 0, LIMIT_TOP_ARTICLE );
    }

    public function get_list( $circle_id, $page=1 ){
        $start = ($page-1) * ARTICLE_COUNT_PAGE;
        $stop = $start + ARTICLE_COUNT_PAGE - 1;
        return $this->redis->zrevrange( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $start, $stop );
    }

    public function del( $circle_id, $article_id, $user_id ){
        $now = time();
        $this->update( $article_id, array( 'status' => ARTICLE_STATUS_DELETE, 'oper_time' => $now ) );

        $this->redis->del( REDIS_KEY_ARITCLE . $article_id );
        $this->redis->zrem( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $article_id );
        $this->redis->zrem( REDIS_KEY_MY_CIRCLE_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $article_id );
    }

    public function set_top( $circle_id, $article_id, $user_id ){
        $cnt = $this->redis->zcard( REDIS_KEY_CIRCLE_TOP_ARTICLE . $circle_id );
        if( $cnt >= LIMIT_TOP_ARTICLE ){
            throw new OpException( '置顶文章数量超过限制', ERROR_CODE_EXCEED );
        }

        $now = time();
        $this->update( $article_id, array( 'status' => ARTICLE_STATUS_TOP, 'oper_time' => $now ) );

        $this->redis->zrem( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $article_id );
        $this->redis->zrem( REDIS_KEY_MY_CIRCLE_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $article_id );

        $this->redis->zAdd( REDIS_KEY_CIRCLE_TOP_ARTICLE . $circle_id, $now, $article_id );
        $this->redis->zAdd( REDIS_KEY_MY_CIRCLE_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $now, $article_id );
    }


    public function cancel_top( $circle_id, $article_id, $user_id ){
        $now = time();
        $this->update( $article_id, array( 'status' => ARTICLE_STATUS_NORMAL, 'oper_time' => $now ) );

        $this->redis->zrem( REDIS_KEY_CIRCLE_TOP_ARTICLE . $circle_id, $article_id );
        $this->redis->zrem( REDIS_KEY_MY_CIRCLE_TOP_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $article_id );

        $this->redis->zAdd( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $now, $article_id );
        $this->redis->zAdd( REDIS_KEY_MY_CIRCLE_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $now, $article_id );
    }

    public function get_attr( $article_id, $attr ){
        return $this->redis->hget( REDIS_KEY_ARITCLE . $article_id, $attr );

    }

    public function get_basic_info( $article_id ){
        return $this->redis->hmget( REDIS_KEY_ARITCLE . $article_id, array(
            'user_id',
            'type',
            'title',
            'banner',
            'abstract',
            'content',
            'create_time'
        ) );

    }

    public function get_info( $article_id ){
        $article_info = $this->redis->hgetall( REDIS_KEY_ARITCLE . $article_id );
        if( !$article_info ){
            $article_info = $this->getById( $article_id );
            if( !$article_info || $article_info['status'] == ARTICLE_STATUS_DELETE ){
                throw new OpException( '文章信息不存在', ERROR_CODE_NOT_EXIST );
            }
            $this->redis->hmset( REDIS_KEY_ARITCLE . $article_id, $article_info );
        }
        return $article_info;
    }


    public function write_simple( $text, $pics, $circle_id, $user_id ){
        $now = time();

        $pics_list = json_decode( $pics );

        $in_data = array(
            'circle_id' => $circle_id,
            'user_id' => $user_id,
            'type' => ARTICLE_TYPE_SIMPLE,
            'abstract' => $text,
            'content' => $pics,
            'status' => ARTICLE_STATUS_NORMAL,
            'create_time' => $now,
            'banner' => $pics_list[0]
        );

        $article_id = $this->insert( $in_data );

        //设置文章缓存
        $this->redis->hmset( REDIS_KEY_ARITCLE . $article_id, $in_data );

        //设置圈子文章列表缓存
        $this->redis->zAdd( REDIS_KEY_CIRCLE_ARTICLE . $circle_id, $now, $article_id );

        //设置圈子中我的文章列表缓存
        $this->redis->zAdd( REDIS_KEY_MY_CIRCLE_ARTICLE . $circle_id . REDIS_SEPARATOR . $user_id, $now, $article_id );

        return $article_id;
    }
}