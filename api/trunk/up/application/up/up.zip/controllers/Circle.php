<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once 'Base_Controller.php';

class Circle extends Base_Controller {

    public function set_name()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $name = $this->get_pos_string( 'name', '圈子名称', false, 4, 32 );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'name', $name );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function set_desc()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $desc = $this->get_pos_string( 'desc', '圈子描述', false, 4, 200 );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'desc', $desc );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function set_thumb()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $thumb = $this->get_pos_url( 'thumb', '圈子头像地址' );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'thumb', $thumb );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function set_banner()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $banner = $this->get_pos_url( 'banner', '圈子banner' );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'banner', $banner );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function set_anyone_view()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $anyone_view = $this->get_pos_if( 'anyone_view', '游客浏览权限' );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'anyone_view', $anyone_view );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function set_join_verify()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $join_verify = $this->get_pos_if( 'join_verify', '入群是否需要审核' );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_attr( $circle_id, $user_id, 'join_verify', $join_verify );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function user_simple_profile()
    {
        try{

            $user_id = $this->get_user();
            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $res = $this->logic->user_simple_profile( $circle_id, $user_id );

            $this->output_data( $res );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function member_remark()
    {
        try{

            $user_id = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $set_user_id = $this->get_pos_int( 'user_id', '用户id', true, 10000,  9999999999);
            $remark = $this->get_pos_string( 'remark', '圈子备注', false, 2, 32 );
            if( !$set_user_id ){
                $set_user_id = $user_id;
            }

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->set_member_remark( $user_id, $set_user_id, $circle_id, $remark );

            $this->output_data_success( );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function kick()
    {
        try{

            $admin_id = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);
            $user_id = $this->get_pos_int( 'user_id', '用户id', false, 10000,  9999999999);

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->kick( $user_id, $circle_id, $admin_id );

            $this->output_data_success( );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function quit()
    {
        try{

            $user_id = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000,  9999999999);

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->quit( $user_id, $circle_id );

            $this->output_data_success( );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function notice()
    {
        try{

            $user_id = $this->get_user();

            $page = $this->get_pos_int( 'page', '时间戳', false, 1,  10000);

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $res = $this->logic->notice_list( $user_id, $page );

            $this->output_data( array( 'list' => $res ) );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function member()
    {
        try{

            $creator = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000, 9999999999 );
            $page = $this->get_pos_int( 'page', '时间戳', false, 1,  10000);

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $res = $this->logic->member_list( $circle_id, $page );

            $this->output_data( $res );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function admin()
    {
        try{

            $creator = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子id', false, 10000, 9999999999 );
            $user_id = $this->get_pos_int( 'user_id', '用户id', false, 10000, 9999999999 );
            $oper = $this->get_pos_if( 'oper', '操作方式' );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->admin( $creator, $circle_id, $user_id, $oper );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function verify()
    {
        try{

            $user_id = $this->get_user();

            $remark = $this->get_pos_string( 'remark', '审核备注', true, 0, 64 );
            $verify_id = $this->get_pos_int( 'verify_id', '审核id', false, 1, 9999999999 );
            $result = $this->get_pos_in( 'result', '审核结果', array( VERIFY_STATUS_PASS, VERIFY_STATUS_REJECT) );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $this->logic->do_verify( $user_id, $verify_id, $result, $remark );

            $this->output_data_success();
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function create()
	{
        try{

            $user_id = $this->get_user();

            $name = $this->get_pos_string( 'name', '圈子名称', false, 2, 32 );
            $desc = $this->get_pos_string( 'desc', '圈子描述', false, 4, 248 );
            $thumb = $this->get_pos_url( 'thumb', '头像' );
            $anyone_view = $this->get_pos_if( 'anyone_view', '游客是否可以浏览' );
            $join_verify = $this->get_pos_if( 'join_verify', '入圈是否需要审核' );
            $code = $this->get_pos_string( 'code', '注册码', false, 6, 6 );

            $this->load->model( 'circle/CodeModel', 'codeModel' );
            $code_id = $this->codeModel->check_code_valid( $code );


            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $circle_id = $this->logic->create( $user_id, array(
                'name' => $name,
                'desc' => $desc,
                'thumb' => $thumb,
                'anyone_view' => $anyone_view,
                'join_verify' => $join_verify
            ) );

            $this->codeModel->set_code_use( $code_id, $circle_id );

            $this->output_data( array( 'circle_id' => $circle_id ) );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
	}

    public function join()
    {
        try{

            $user_id = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子ID', false, 10001, 99999999 );
            $remark = $this->get_pos_string( 'remark', '申请备注', true, 0, 60 );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $result = $this->logic->join( $circle_id, $user_id, $remark);

            $this->output_data( array( 'result' => $result ) );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }


    public function profile()
    {
        try{
            $user_id = $this->get_user();

            $circle_id = $this->get_pos_int( 'circle_id', '圈子ID', false, 10001, 99999999 );

            $this->load->model( 'circle/CircleLogicModel', 'logic' );

            $data = $this->logic->get_basic_info( $circle_id, $user_id );

            $this->output_data( $data );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

}
