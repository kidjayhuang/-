<?php
defined('BASEPATH') OR exit('No direct script access allowed');

require_once 'Base_Controller.php';

class Article extends Base_Controller {

    public function __construct() {
        parent::__construct();
    }

    public function hot_topic(){

        try{
            $this->_init();
            $res = $this->logic->hot_topic();
            $this->output_data( $res );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function reply_list(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章id', false, 1, 99999999 );
            $page = $this->get_pos_int( 'page', '页码', false, 1, 99999999 );
            $res = $this->logic->reply_list( $article_id, $page );
            $this->output_data( $res );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function like_list(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章id', false, 1, 99999999 );
            $res = $this->logic->like_list( $article_id );
            $this->output_data( array( 'list' => $res ) );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function rich_info(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章id', false, 1, 99999999 );
            $res = $this->logic->rich_info( $article_id );
            $this->output_data( $res );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function topic_article_list(){

        try{
            $this->_init();
            $page = $this->get_pos_int( 'page', '页码', false, 1, 99999999 );
            $topic = $this->get_pos_string( 'topic', '话题名称', false, 2, LIMIT_TOPIC_LENGTH );
            $res = $this->logic->topic_article_list( $topic, $page );
            $this->output_data( $res );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function article_list(){

        try{
            $this->_init();
            $page = $this->get_pos_int( 'page', '页码', false, 1, 99999999 );
            $res = $this->logic->article_list( $page );
            $this->output_data( $res );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function like(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章id', false, 1, 99999999 );
            $type = $this->get_pos_if( 'type', '操作类型' );
            $this->logic->like( $article_id, $type );
            $this->output_data_success();

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function del_reply(){

        try{
            $this->_init();
            $reply_id = $this->get_pos_int( 'reply_id', '回复id', false, 1, 99999999 );
            $this->logic->del_reply( $reply_id );
            $this->output_data_success();

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function reply(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章ID', false, 1, 99999999 );
            $to_user_id = $this->get_pos_int( 'to_user_id', '回复的对象', false, 0, 99999999 );
            $type = $this->get_pos_int( 'type', '回复的类型', false, 101, 102 );
            $content = $this->get_pos_string( 'content', '回复内容', false, 0, LIMIT_SIMPLE_ARTICLE_TEXT_MAX );

            $reply_id = $this->logic->do_reply( $article_id, $to_user_id, $type, $content );
            $this->output_data( array( 'reply_id' => $reply_id ) );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function get_recommend_topic(){

        try{
            $this->_init();

            $topic_list = $this->logic->get_recommend_topic( );
            $this->output_data( array( 'list' => $topic_list ));

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function del(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章ID', false, 1, 99999999 );
            $this->logic->del( $article_id );
            $this->output_data_success();

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function top(){

        try{
            $this->_init();
            $article_id = $this->get_pos_int( 'article_id', '文章ID', false, 1, 99999999 );
            $type = $this->get_pos_if( 'type', '置顶类型' );

            $this->logic->top_oper( $article_id, $type );
            $this->output_data_success();

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function set_recommend_topic(){

        try{
            $this->_init();
            $text = $this->get_pos_string( 'text', '话题列表', false, 0, LIMIT_SIMPLE_ARTICLE_TEXT_MAX );

            $this->logic->set_recommend_topic( $text );
            $this->output_data_success();

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function write_simple()
    {
        try{
            $this->_init();
            $text = $this->get_pos_string( 'text', '文字', false, LIMIT_SIMPLE_ARTICLE_TEXT_MIN, LIMIT_SIMPLE_ARTICLE_TEXT_MAX );
            $pic_json_str = $this->get_pos_string( 'pics', '照片列表', false, LIMIT_SIMPLE_ARTICLE_TEXT_MIN, LIMIT_SIMPLE_ARTICLE_TEXT_MAX );
            $pic_list = json_decode( $pic_json_str );
            if( is_array( $pic_list ) && count( $pic_list ) ){
                foreach( $pic_list as $pic ){
                    if( !filter_var( $pic, FILTER_VALIDATE_URL )){
                        throw new OpException( '照片URL格式不合法', ERROR_CODE_PARAM_INVALID );
                    }
                }
            }
            else{
                throw new OpException('照片列表格式错误', ERROR_CODE_PARAM_INVALID);
            }
            $article_id = $this->logic->write_simple( $text, $pic_json_str );
            $this->output_data( array( 'article_id' => $article_id ) );

        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    public function test()
    {
        try{
            $time = time() - 86400*3-20000;
            $this->output_data( array( 'text' => timestamp_trans( $time ) ) );
        } catch ( OpException $e) {
            $this->deal_with_opexception($e);
        }
    }

    /*
     * 文章必定跟圈子相关，因此圈子id必须获取
     * 同时作为统一入口，可以做公共操作，比如记录成员的登陆时间
     */
    private function _init(){
        $user_id = $this->get_user();
        $circle_id = $this->get_pos_int( 'circle_id', '圈子ID', false, 10001, 99999999 );

        $this->load->model( 'circle/CircleModel', 'circle' );

        $circle_info = $this->circle->get_basic_info( $circle_id );
        if( !$circle_info ){
            throw new OpException('圈子不存在', ERROR_CODE_NOT_EXIST);
        }

        $this->load->model( 'article/ArticleLogicModel', 'logic' );
        $this->logic->init( $user_id, $circle_id, $circle_info );

    }

}
